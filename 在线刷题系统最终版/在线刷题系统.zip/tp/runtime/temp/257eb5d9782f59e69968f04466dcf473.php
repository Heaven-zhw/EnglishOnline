<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:66:"F:\php\WWW\tp5\tp\public/../application/index\view\test\index.html";i:1557906118;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <script>
        alert("<?php echo $id+1; ?>");
    </script>
</head>
<body>
<h1>sdsd</h1>
</body>
</html>