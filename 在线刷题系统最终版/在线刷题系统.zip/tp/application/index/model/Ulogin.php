<?php
namespace app\index\model;
use think\Model;
class Ulogin extends Model{
    protected $table='ulogin';
}