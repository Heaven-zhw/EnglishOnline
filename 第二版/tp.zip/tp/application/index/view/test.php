<!DOCTYPE html>
<html>
    <meta charset="utf-8">
    <title>在线考试</title>
    <link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <body style="background-color:#f5f5f5">

        <nav class="navbar-inverse" >
            <div class="container-fluid">
                <div class="navbar-header">
                     <a class="navbar-brand" herf="#"> 在线测试</a>
                     <p class="navbar-text"> <?php echo"林军任 欢迎你"?> </p>
                </div>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#"><span class="glyphicon glyphicon-log-out">退出登录</span></a></li>
                </ul>
            </div>
        </nav>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-7 col-md-offset-2">
                </br></br><hr style="solid-color: #0D3349"></div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-sm-6 col-lg-offset-1">

                </div>
            </div>
        </div>
    </body>
</html>