<?php


namespace app\index\controller;


class collocation
{

}