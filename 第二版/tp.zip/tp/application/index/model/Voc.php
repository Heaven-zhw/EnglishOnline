<?php
namespace app\index\model;
use think\Model;
class Voc extends Model{
    protected $table='voc';
}