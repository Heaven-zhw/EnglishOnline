<?php
namespace app\index\model;
use think\Model;
class Readtext extends Model{
    protected $table='readtext';
}
