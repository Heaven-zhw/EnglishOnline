<?php
namespace app\index\model;
use think\Model;
class Squestions extends Model{
    protected $table='squestion';
}