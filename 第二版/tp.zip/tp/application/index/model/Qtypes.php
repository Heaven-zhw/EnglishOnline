<?php
namespace app\index\model;
use think\Model;
class Qtypes extends Model{
    protected $table='qtypes';
}
