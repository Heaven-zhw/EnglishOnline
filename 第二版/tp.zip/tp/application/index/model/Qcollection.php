<?php
namespace app\index\model;
use think\Model;
class Qcollection extends Model{
    protected $table='qcollection';
}
