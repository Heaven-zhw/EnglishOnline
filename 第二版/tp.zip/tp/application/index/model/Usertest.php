<?php
namespace app\index\model;
use think\Model;
class Usertest extends Model{
    protected $table='usertest';
}
