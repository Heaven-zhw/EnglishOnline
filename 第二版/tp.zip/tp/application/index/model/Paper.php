<?php
namespace app\index\model;
use think\Model;
class Paper extends Model{
    protected $table='paper';
}