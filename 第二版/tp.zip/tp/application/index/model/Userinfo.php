<?php
namespace app\index\model;
use think\Model;
class Userinfo extends Model{
    protected $table='userinfo';
}
